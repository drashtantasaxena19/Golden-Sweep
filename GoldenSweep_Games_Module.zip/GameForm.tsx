import { useState } from "react";
import { Loader2, Save } from "lucide-react";

import {
    GAME_CATEGORY_OPTIONS,
    GAME_ORIENTATION_OPTIONS,
    GAME_STATUS_OPTIONS,
} from "../../../types/game";
import type {
    GameCreate,
    GameResponse,
    GameUpdate,
} from "../../../types/game";

type GameFormValues = GameCreate & Partial<Pick<GameUpdate, "status">>;

interface GameFormProps {
    mode: "create" | "edit";
    loading: boolean;
    initialValues?: GameResponse;
    onSubmit: (values: GameFormValues) => void;
    onCancel: () => void;
}

const buildInitialState = (
    initialValues?: GameResponse
): GameFormValues => ({
    name: initialValues?.name ?? "",
    slug: initialValues?.slug ?? "",
    short_description: initialValues?.short_description ?? "",
    description: initialValues?.description ?? "",
    category: initialValues?.category ?? "other",
    game_url: initialValues?.game_url ?? "",
    entry_fee_coins: initialValues?.entry_fee_coins ?? 0,
    minimum_age: initialValues?.minimum_age ?? 18,
    provider_name: initialValues?.provider_name ?? "",
    provider_game_id: initialValues?.provider_game_id ?? "",
    orientation: initialValues?.orientation ?? "responsive",
    tags: initialValues?.tags ?? [],
    instructions: initialValues?.instructions ?? "",
    terms_and_conditions: initialValues?.terms_and_conditions ?? "",
    status: initialValues?.status ?? "draft",
    is_featured: initialValues?.is_featured ?? false,
    show_on_landing_page: initialValues?.show_on_landing_page ?? true,
    sort_order: initialValues?.sort_order ?? 0,
    opens_in_new_tab: initialValues?.opens_in_new_tab ?? true,
    is_mobile_supported: initialValues?.is_mobile_supported ?? true,
    is_desktop_supported: initialValues?.is_desktop_supported ?? true,
});

const slugify = (value: string) =>
    value
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "");

const GameForm = ({
    mode,
    loading,
    initialValues,
    onSubmit,
    onCancel,
}: GameFormProps) => {
    const [values, setValues] = useState<GameFormValues>(
        buildInitialState(initialValues)
    );
    const [tagsInput, setTagsInput] = useState(
        (initialValues?.tags ?? []).join(", ")
    );
    const [slugTouched, setSlugTouched] = useState(mode === "edit");

    const update = <K extends keyof GameFormValues>(
        key: K,
        value: GameFormValues[K]
    ) => setValues((prev) => ({ ...prev, [key]: value }));

    const handleNameChange = (name: string) => {
        update("name", name);
        if (!slugTouched) {
            update("slug", slugify(name));
        }
    };

    const handleSubmit = (event: React.FormEvent) => {
        event.preventDefault();

        const tags = tagsInput
            .split(",")
            .map((tag) => tag.trim().toLowerCase())
            .filter(Boolean);

        onSubmit({
            ...values,
            slug: slugify(values.slug),
            tags,
            provider_name: values.provider_name || undefined,
            provider_game_id: values.provider_game_id || undefined,
            instructions: values.instructions || undefined,
            terms_and_conditions: values.terms_and_conditions || undefined,
        });
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-6 text-slate-200">
            <div className="grid gap-6 rounded-2xl border border-yellow-500/15 bg-[#0A0C12] p-6 shadow-[0_20px_50px_rgba(0,0,0,0.35)] md:grid-cols-2 lg:p-8">
                <div className="md:col-span-2">
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Game Name
                    </label>
                    <input
                        required
                        minLength={2}
                        maxLength={120}
                        value={values.name}
                        onChange={(event) =>
                            handleNameChange(event.target.value)
                        }
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                        placeholder="Golden Sweep Slots"
                    />
                </div>

                <div>
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Slug
                    </label>
                    <input
                        required
                        minLength={2}
                        maxLength={140}
                        value={values.slug}
                        onChange={(event) => {
                            setSlugTouched(true);
                            update("slug", event.target.value);
                        }}
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 font-mono text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                        placeholder="golden-sweep-slots"
                    />
                </div>

                <div>
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Category
                    </label>
                    <select
                        value={values.category}
                        onChange={(event) =>
                            update(
                                "category",
                                event.target
                                    .value as GameFormValues["category"]
                            )
                        }
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                    >
                        {GAME_CATEGORY_OPTIONS.map((category) => (
                            <option key={category} value={category}>
                                {category.charAt(0).toUpperCase() +
                                    category.slice(1)}
                            </option>
                        ))}
                    </select>
                </div>

                <div className="md:col-span-2">
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Short Description
                    </label>
                    <input
                        required
                        minLength={10}
                        maxLength={240}
                        value={values.short_description}
                        onChange={(event) =>
                            update("short_description", event.target.value)
                        }
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                        placeholder="A one-line teaser shown in game cards"
                    />
                </div>

                <div className="md:col-span-2">
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Description
                    </label>
                    <textarea
                        required
                        minLength={20}
                        maxLength={5000}
                        rows={5}
                        value={values.description}
                        onChange={(event) =>
                            update("description", event.target.value)
                        }
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                        placeholder="Full game description"
                    />
                </div>

                <div className="md:col-span-2">
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Game URL
                    </label>
                    <input
                        required
                        type="url"
                        value={values.game_url}
                        onChange={(event) =>
                            update("game_url", event.target.value)
                        }
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                        placeholder="https://provider.example.com/embed/game"
                    />
                </div>

                <div>
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Provider Name
                    </label>
                    <input
                        maxLength={120}
                        value={values.provider_name ?? ""}
                        onChange={(event) =>
                            update("provider_name", event.target.value)
                        }
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                    />
                </div>

                <div>
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Provider Game ID
                    </label>
                    <input
                        maxLength={160}
                        value={values.provider_game_id ?? ""}
                        onChange={(event) =>
                            update("provider_game_id", event.target.value)
                        }
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                    />
                </div>

                <div>
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Orientation
                    </label>
                    <select
                        value={values.orientation}
                        onChange={(event) =>
                            update(
                                "orientation",
                                event.target
                                    .value as GameFormValues["orientation"]
                            )
                        }
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                    >
                        {GAME_ORIENTATION_OPTIONS.map((orientation) => (
                            <option key={orientation} value={orientation}>
                                {orientation.charAt(0).toUpperCase() +
                                    orientation.slice(1)}
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Status
                    </label>
                    <select
                        value={values.status}
                        onChange={(event) =>
                            update(
                                "status",
                                event.target
                                    .value as GameFormValues["status"]
                            )
                        }
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                    >
                        {GAME_STATUS_OPTIONS.map((status) => (
                            <option key={status} value={status}>
                                {status.charAt(0).toUpperCase() +
                                    status.slice(1)}
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Entry Fee (coins)
                    </label>
                    <input
                        type="number"
                        min={0}
                        value={values.entry_fee_coins}
                        onChange={(event) =>
                            update(
                                "entry_fee_coins",
                                Number(event.target.value)
                            )
                        }
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                    />
                </div>

                <div>
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Minimum Age
                    </label>
                    <input
                        type="number"
                        min={0}
                        max={100}
                        value={values.minimum_age}
                        onChange={(event) =>
                            update(
                                "minimum_age",
                                Number(event.target.value)
                            )
                        }
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                    />
                </div>

                <div>
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Sort Order
                    </label>
                    <input
                        type="number"
                        min={0}
                        value={values.sort_order}
                        onChange={(event) =>
                            update("sort_order", Number(event.target.value))
                        }
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                    />
                </div>

                <div className="md:col-span-2">
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Tags (comma separated)
                    </label>
                    <input
                        value={tagsInput}
                        onChange={(event) =>
                            setTagsInput(event.target.value)
                        }
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                        placeholder="slots, jackpot, high-volatility"
                    />
                </div>

                <div className="md:col-span-2">
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Instructions
                    </label>
                    <textarea
                        rows={3}
                        maxLength={5000}
                        value={values.instructions ?? ""}
                        onChange={(event) =>
                            update("instructions", event.target.value)
                        }
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                    />
                </div>

                <div className="md:col-span-2">
                    <label className="mb-2 block text-sm font-medium text-slate-300">
                        Terms &amp; Conditions
                    </label>
                    <textarea
                        rows={3}
                        maxLength={5000}
                        value={values.terms_and_conditions ?? ""}
                        onChange={(event) =>
                            update(
                                "terms_and_conditions",
                                event.target.value
                            )
                        }
                        className="w-full rounded-xl border border-white/10 bg-[#11141C] px-4 py-3 text-sm text-white placeholder:text-slate-600 outline-none transition focus:border-yellow-400/60 focus:ring-2 focus:ring-yellow-400/10"
                    />
                </div>

                <div className="flex flex-wrap gap-6 md:col-span-2">
                    <label className="flex items-center gap-2 text-sm text-slate-300">
                        <input
                            type="checkbox"
                            checked={values.is_featured}
                            onChange={(event) =>
                                update("is_featured", event.target.checked)
                            }
                            className="h-4 w-4 rounded border-white/20 bg-[#11141C] text-yellow-400 accent-yellow-400 focus:ring-yellow-400"
                        />
                        Featured
                    </label>

                    <label className="flex items-center gap-2 text-sm text-slate-300">
                        <input
                            type="checkbox"
                            checked={values.show_on_landing_page}
                            onChange={(event) =>
                                update(
                                    "show_on_landing_page",
                                    event.target.checked
                                )
                            }
                            className="h-4 w-4 rounded border-white/20 bg-[#11141C] text-yellow-400 accent-yellow-400 focus:ring-yellow-400"
                        />
                        Show on landing page
                    </label>

                    <label className="flex items-center gap-2 text-sm text-slate-300">
                        <input
                            type="checkbox"
                            checked={values.opens_in_new_tab}
                            onChange={(event) =>
                                update(
                                    "opens_in_new_tab",
                                    event.target.checked
                                )
                            }
                            className="h-4 w-4 rounded border-white/20 bg-[#11141C] text-yellow-400 accent-yellow-400 focus:ring-yellow-400"
                        />
                        Opens in new tab
                    </label>

                    <label className="flex items-center gap-2 text-sm text-slate-300">
                        <input
                            type="checkbox"
                            checked={values.is_mobile_supported}
                            onChange={(event) =>
                                update(
                                    "is_mobile_supported",
                                    event.target.checked
                                )
                            }
                            className="h-4 w-4 rounded border-white/20 bg-[#11141C] text-yellow-400 accent-yellow-400 focus:ring-yellow-400"
                        />
                        Mobile supported
                    </label>

                    <label className="flex items-center gap-2 text-sm text-slate-300">
                        <input
                            type="checkbox"
                            checked={values.is_desktop_supported}
                            onChange={(event) =>
                                update(
                                    "is_desktop_supported",
                                    event.target.checked
                                )
                            }
                            className="h-4 w-4 rounded border-white/20 bg-[#11141C] text-yellow-400 accent-yellow-400 focus:ring-yellow-400"
                        />
                        Desktop supported
                    </label>
                </div>
            </div>

            <div className="flex items-center justify-end gap-3">
                <button
                    type="button"
                    onClick={onCancel}
                    disabled={loading}
                    className="rounded-xl border border-white/10 bg-white/[0.03] px-5 py-3 font-semibold text-slate-300 transition hover:border-yellow-400/25 hover:text-yellow-400 disabled:opacity-60"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    disabled={loading}
                    className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-yellow-500 to-amber-400 px-5 py-3 font-semibold text-black shadow-[0_10px_25px_rgba(234,179,8,0.2)] transition hover:brightness-110 disabled:opacity-60"
                >
                    {loading ? (
                        <Loader2 size={18} className="animate-spin" />
                    ) : (
                        <Save size={18} />
                    )}
                    {mode === "create" ? "Create Game" : "Save Changes"}
                </button>
            </div>
        </form>
    );
};

export default GameForm;