import gameApi from "../api/gameApi";

import type {
    GameCreate,
    GameFilter,
    GameImageType,
    GameStatus,
    GameUpdate,
} from "../types/game";

class GameService {
    getStatistics() {
        return gameApi.getStatistics();
    }

    listAdminGames(filters: GameFilter = {}) {
        return gameApi.listAdminGames(filters);
    }

    getAdminGame(gameId: string) {
        return gameApi.getAdminGame(gameId);
    }

    createGame(payload: GameCreate) {
        return gameApi.createGame(payload);
    }

    updateGame(gameId: string, payload: GameUpdate) {
        return gameApi.updateGame(gameId, payload);
    }

    deleteGame(gameId: string) {
        return gameApi.deleteGame(gameId);
    }

    publishGame(gameId: string) {
        return gameApi.publishGame(gameId);
    }

    unpublishGame(gameId: string) {
        return gameApi.unpublishGame(gameId);
    }

    setGameStatus(gameId: string, status: GameStatus) {
        return gameApi.setGameStatus(gameId, status);
    }

    featureGame(gameId: string) {
        return gameApi.featureGame(gameId);
    }

    unfeatureGame(gameId: string) {
        return gameApi.unfeatureGame(gameId);
    }

    setFeatured(gameId: string, isFeatured: boolean) {
        return isFeatured
            ? gameApi.featureGame(gameId)
            : gameApi.unfeatureGame(gameId);
    }

    showOnLandingPage(gameId: string) {
        return gameApi.showOnLandingPage(gameId);
    }

    hideFromLandingPage(gameId: string) {
        return gameApi.hideFromLandingPage(gameId);
    }

    setLandingPageVisibility(gameId: string, show: boolean) {
        return show
            ? gameApi.showOnLandingPage(gameId)
            : gameApi.hideFromLandingPage(gameId);
    }

    reorderGame(gameId: string, sortOrder: number) {
        return gameApi.reorderGame(gameId, sortOrder);
    }

    uploadGameImage(gameId: string, imageType: GameImageType, file: File) {
        return gameApi.uploadGameImage(gameId, imageType, file);
    }

    uploadGameImages(
        gameId: string,
        files: Partial<Record<GameImageType, File>>
    ) {
        return gameApi.uploadGameImages(gameId, files);
    }

    getGameImageMetadata(gameId: string, imageType: GameImageType) {
        return gameApi.getGameImageMetadata(gameId, imageType);
    }

    deleteGameImage(gameId: string, imageType: GameImageType) {
        return gameApi.deleteGameImage(gameId, imageType);
    }

    deleteAllGameImages(gameId: string) {
        return gameApi.deleteAllGameImages(gameId);
    }

    validateGameImages(gameId: string) {
        return gameApi.validateGameImages(gameId);
    }

    getImageUrl(fileId: string) {
        return gameApi.getImageUrl(fileId);
    }

    bulkUpdateStatus(gameIds: string[], status: GameStatus) {
        return gameApi.bulkUpdateStatus(gameIds, status);
    }

    bulkFeatureGames(gameIds: string[], isFeatured: boolean) {
        return gameApi.bulkFeatureGames(gameIds, isFeatured);
    }

    bulkLandingPageUpdate(gameIds: string[], showOnLandingPage: boolean) {
        return gameApi.bulkLandingPageUpdate(gameIds, showOnLandingPage);
    }

    bulkDeleteGames(gameIds: string[]) {
        return gameApi.bulkDeleteGames(gameIds);
    }

    listPublicGames(params?: {
        page?: number;
        limit?: number;
        category?: string;
        featured_only?: boolean;
    }) {
        return gameApi.listPublicGames(params ?? {});
    }

    getPublicGame(slug: string) {
        return gameApi.getPublicGame(slug);
    }

    registerGamePlay(gameId: string) {
        return gameApi.registerGamePlay(gameId);
    }
}

export const gameService = new GameService();

export default gameService;