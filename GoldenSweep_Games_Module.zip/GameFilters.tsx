import { Search } from "lucide-react";

import {
    GAME_CATEGORY_LABELS,
    GAME_CATEGORY_OPTIONS,
    GAME_STATUS_LABELS,
    GAME_STATUS_OPTIONS,
} from "../../../types/game";

import type {
    GameCategory,
    GameFilter,
    GameStatus,
} from "../../../types/game";

interface GameFiltersProps {
    filters: GameFilter;
    onChange: (filters: GameFilter) => void;
}

const GameFilters = ({
    filters,
    onChange,
}: GameFiltersProps) => {
    const updateFilter = <K extends keyof GameFilter>(
        key: K,
        value: GameFilter[K]
    ) => {
        onChange({
            ...filters,
            [key]: value,
            page: 1,
        });
    };

    const resetFilters = () => {
        onChange({
            page: 1,
            limit: filters.limit ?? 20,
        });
    };

    return (
        <div className="flex flex-wrap items-center gap-3 rounded-xl border bg-white p-4 shadow-sm">
            <div className="relative min-w-[220px] flex-1">
                <Search
                    size={18}
                    className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                />

                <input
                    type="text"
                    value={filters.search ?? ""}
                    onChange={(event) =>
                        updateFilter(
                            "search",
                            event.target.value.trimStart() || undefined
                        )
                    }
                    placeholder="Search by title, slug, provider..."
                    className="w-full rounded-lg border py-2 pl-10 pr-3 text-sm focus:border-yellow-500 focus:outline-none"
                />
            </div>

            <select
                value={filters.status ?? ""}
                onChange={(event) =>
                    updateFilter(
                        "status",
                        event.target.value
                            ? (event.target.value as GameStatus)
                            : undefined
                    )
                }
                className="rounded-lg border px-3 py-2 text-sm focus:border-yellow-500 focus:outline-none"
                aria-label="Filter games by status"
            >
                <option value="">All Statuses</option>

                {GAME_STATUS_OPTIONS.map((status) => (
                    <option key={status} value={status}>
                        {GAME_STATUS_LABELS[status]}
                    </option>
                ))}
            </select>

            <select
                value={filters.category ?? ""}
                onChange={(event) =>
                    updateFilter(
                        "category",
                        event.target.value
                            ? (event.target.value as GameCategory)
                            : undefined
                    )
                }
                className="rounded-lg border px-3 py-2 text-sm focus:border-yellow-500 focus:outline-none"
                aria-label="Filter games by category"
            >
                <option value="">All Categories</option>

                {GAME_CATEGORY_OPTIONS.map((category) => (
                    <option key={category} value={category}>
                        {GAME_CATEGORY_LABELS[category]}
                    </option>
                ))}
            </select>

            <label className="flex items-center gap-2 text-sm text-gray-600">
                <input
                    type="checkbox"
                    checked={filters.is_featured === true}
                    onChange={(event) =>
                        updateFilter(
                            "is_featured",
                            event.target.checked ? true : undefined
                        )
                    }
                    className="h-4 w-4 rounded border-gray-300 text-yellow-500 focus:ring-yellow-500"
                />

                Featured only
            </label>

            <label className="flex items-center gap-2 text-sm text-gray-600">
                <input
                    type="checkbox"
                    checked={filters.show_on_landing_page === true}
                    onChange={(event) =>
                        updateFilter(
                            "show_on_landing_page",
                            event.target.checked ? true : undefined
                        )
                    }
                    className="h-4 w-4 rounded border-gray-300 text-yellow-500 focus:ring-yellow-500"
                />

                On landing page
            </label>

            <button
                type="button"
                onClick={resetFilters}
                className="ml-auto rounded-lg border px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-50"
            >
                Reset filters
            </button>
        </div>
    );
};

export default GameFilters;