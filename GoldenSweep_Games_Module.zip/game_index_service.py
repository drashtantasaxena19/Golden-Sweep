from __future__ import annotations

import inspect

from app.core.database import get_database
from app.repositories.game_repository import GameRepository
from app.services.gridfs_storage_service import GridFSStorageService


async def _resolve_database():
    """`get_database` is normally used as a FastAPI `Depends` callable
    elsewhere in this codebase (see app/api/game_routes.py), so its exact
    return shape (plain value, coroutine, or async generator) isn't known
    at this call site. Resolve it defensively so this works the same way
    during app startup (outside of FastAPI's dependency-injection system).
    """
    result = get_database()

    if inspect.isasyncgen(result):
        return await result.__anext__()

    if inspect.isawaitable(result):
        return await result

    return result


async def initialize_game_indexes() -> None:
    """Create MongoDB indexes for the games collection and the GridFS
    game-images bucket. Called once during application startup (see the
    lifespan handler in app/main.py).
    """
    database = await _resolve_database()

    game_repository = GameRepository(database)
    await game_repository.create_indexes()

    gridfs_storage = GridFSStorageService(database)
    await gridfs_storage.create_indexes()