import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

import GameForm from "../../components/admin/games/GameForm";
import gameService from "../../services/gameService";
import type { GameCreate } from "../../types/game";

const CreateGame = () => {
    const navigate = useNavigate();

    const [loading, setLoading] = useState(false);

    const createGame = async (
        values: GameCreate,
    ) => {
        try {
            setLoading(true);

            const game =
                await gameService.createGame(values);

            navigate(
                `/admin/games/${game.id}`,
            );
        } catch (error: unknown) {
            console.error("Create game failed:", error);

            const apiError = error as {
                response?: {
                    data?: {
                        detail?: string | Array<{
                            loc?: Array<string | number>;
                            msg?: string;
                        }>;
                        message?: string;
                    };
                };
                message?: string;
            };

            const detail = apiError.response?.data?.detail;

            let message = "Unable to create game.";

            if (typeof detail === "string") {
                message = detail;
            } else if (Array.isArray(detail)) {
                message = detail
                    .map((item) => {
                        const field = item.loc?.slice(1).join(".") || "field";
                        return `${field}: ${item.msg || "Invalid value"}`;
                    })
                    .join("\n");
            } else if (apiError.response?.data?.message) {
                message = apiError.response.data.message;
            } else if (apiError.message) {
                message = apiError.message;
            }

            alert(message);
        } finally {
        setLoading(false);
    }
};

return (
    <div className="space-y-6 text-slate-200">

        <div className="flex items-center gap-4">

            <button
                onClick={() =>
                    navigate("/admin/games")
                }
                className="rounded-xl border border-yellow-400/20 bg-[#11141C] p-2.5 text-slate-300 transition hover:border-yellow-400/40 hover:bg-yellow-400/10 hover:text-yellow-400"
            >
                <ArrowLeft size={20} />
            </button>

            <div>

                <h1 className="text-3xl font-bold tracking-tight text-white">
                    Create Game
                </h1>

                <p className="mt-1 text-slate-500">
                    Add a new GoldenSweep game
                </p>

            </div>

        </div>

        <GameForm
            mode="create"
            loading={loading}
            onSubmit={createGame}
            onCancel={() =>
                navigate("/admin/games")
            }
        />

    </div>
);
};

export default CreateGame;