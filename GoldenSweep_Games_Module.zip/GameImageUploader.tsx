import { useRef, useState } from "react";
import { ImageIcon, Loader2, Trash2, Upload } from "lucide-react";

import gameApi from "../../../api/gameApi";
import gameService from "../../../services/gameService";
import type { GameImageType } from "../../../types/game";

interface GameImageUploaderProps {
    gameId: string;
    imageType: GameImageType;
    label: string;
    fileId?: string | null;
    onChanged: (fileId: string | null) => void;
}

const ACCEPTED_TYPES = "image/jpeg,image/png,image/webp";

const GameImageUploader = ({
    gameId,
    imageType,
    label,
    fileId,
    onChanged,
}: GameImageUploaderProps) => {
    const inputRef = useRef<HTMLInputElement>(null);

    const [uploading, setUploading] = useState(false);
    const [deleting, setDeleting] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleFileSelected = async (
        event: React.ChangeEvent<HTMLInputElement>
    ) => {
        const file = event.target.files?.[0];
        event.target.value = "";
        if (!file) return;

        try {
            setError(null);
            setUploading(true);

            const response = await gameService.uploadGameImage(
                gameId,
                imageType,
                file
            );

            onChanged(response.image.file_id);
        } catch (uploadError) {
            console.error(uploadError);
            setError("Upload failed. Use JPG, PNG, or WEBP under 5MB.");
        } finally {
            setUploading(false);
        }
    };

    const handleDelete = async () => {
        if (!fileId) return;

        try {
            setError(null);
            setDeleting(true);

            await gameService.deleteGameImage(gameId, imageType);

            onChanged(null);
        } catch (deleteError) {
            console.error(deleteError);
            setError("Unable to remove image.");
        } finally {
            setDeleting(false);
        }
    };

    return (
        <div className="rounded-xl border bg-white p-4 shadow-sm">
            <p className="mb-3 text-sm font-semibold text-gray-700">
                {label}
            </p>

            <div className="mb-3 flex h-40 items-center justify-center overflow-hidden rounded-lg border bg-gray-50">
                {fileId ? (
                    <img
                        src={gameApi.getImageUrl(fileId)}
                        alt={label}
                        className="h-full w-full object-cover"
                    />
                ) : (
                    <ImageIcon size={32} className="text-gray-300" />
                )}
            </div>

            {error && (
                <p className="mb-2 text-xs text-red-600">{error}</p>
            )}

            <div className="flex gap-2">
                <button
                    type="button"
                    onClick={() => inputRef.current?.click()}
                    disabled={uploading || deleting}
                    className="flex flex-1 items-center justify-center gap-2 rounded-lg border px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-60"
                >
                    {uploading ? (
                        <Loader2 size={14} className="animate-spin" />
                    ) : (
                        <Upload size={14} />
                    )}
                    {fileId ? "Replace" : "Upload"}
                </button>

                {fileId && (
                    <button
                        type="button"
                        onClick={handleDelete}
                        disabled={uploading || deleting}
                        className="flex items-center justify-center gap-2 rounded-lg border border-red-200 px-3 py-2 text-sm font-medium text-red-600 hover:bg-red-50 disabled:opacity-60"
                    >
                        {deleting ? (
                            <Loader2 size={14} className="animate-spin" />
                        ) : (
                            <Trash2 size={14} />
                        )}
                    </button>
                )}
            </div>

            <input
                ref={inputRef}
                type="file"
                accept={ACCEPTED_TYPES}
                className="hidden"
                onChange={handleFileSelected}
            />
        </div>
    );
};

export default GameImageUploader;