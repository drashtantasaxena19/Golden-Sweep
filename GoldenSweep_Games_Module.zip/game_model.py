from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def build_game_document(payload: dict[str, Any], *, created_by: str | None = None) -> dict[str, Any]:
    now = utc_now()
    document = dict(payload)
    if "game_url" in document:
        document["game_url"] = str(document["game_url"])
    document.update({"play_count": 0, "created_by": created_by, "updated_by": created_by, "created_at": now, "updated_at": now})
    return document


def build_game_update_document(payload: dict[str, Any], *, updated_by: str | None = None) -> dict[str, Any]:
    document = dict(payload)
    if "game_url" in document and document["game_url"] is not None:
        document["game_url"] = str(document["game_url"])
    document["updated_by"] = updated_by
    document["updated_at"] = utc_now()
    return document


def serialize_game_document(document: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": str(document["_id"]), "name": document["name"], "slug": document["slug"],
        "short_description": document["short_description"], "description": document["description"],
        "category": document.get("category", "other"), "game_url": str(document["game_url"]),
        "logo_file_id": str(document["logo_file_id"]) if document.get("logo_file_id") else None,
        "thumbnail_file_id": str(document["thumbnail_file_id"]) if document.get("thumbnail_file_id") else None,
        "banner_file_id": str(document["banner_file_id"]) if document.get("banner_file_id") else None,
        "entry_fee_coins": int(document.get("entry_fee_coins", 0)), "minimum_age": int(document.get("minimum_age", 18)),
        "provider_name": document.get("provider_name"), "provider_game_id": document.get("provider_game_id"),
        "orientation": document.get("orientation", "responsive"), "tags": list(document.get("tags", [])),
        "instructions": document.get("instructions"), "terms_and_conditions": document.get("terms_and_conditions"),
        "status": document.get("status", "draft"), "is_featured": bool(document.get("is_featured", False)),
        "show_on_landing_page": bool(document.get("show_on_landing_page", True)), "sort_order": int(document.get("sort_order", 0)),
        "opens_in_new_tab": bool(document.get("opens_in_new_tab", True)),
        "is_mobile_supported": bool(document.get("is_mobile_supported", True)),
        "is_desktop_supported": bool(document.get("is_desktop_supported", True)),
        "play_count": int(document.get("play_count", 0)), "created_by": document.get("created_by"),
        "updated_by": document.get("updated_by"), "created_at": document["created_at"], "updated_at": document["updated_at"],
    }
