from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, AsyncIterator, Final, Optional

from bson import ObjectId
from fastapi import UploadFile
from gridfs.errors import NoFile

from pymongo.asynchronous.database import AsyncDatabase
from gridfs.asynchronous import AsyncGridFSBucket

ALLOWED_IMAGE_CONTENT_TYPES: Final[dict[str, str]] = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
}

DEFAULT_MAX_IMAGE_SIZE_BYTES: Final[int] = 5 * 1024 * 1024
DEFAULT_CHUNK_SIZE_BYTES: Final[int] = 255 * 1024
DEFAULT_BUCKET_NAME: Final[str] = "game_images"


class GridFSStorageError(Exception):
    pass


class GridFSInvalidFileError(GridFSStorageError):
    pass


class GridFSFileTooLargeError(GridFSStorageError):
    pass


class GridFSFileNotFoundError(GridFSStorageError):
    pass


@dataclass(frozen=True)
class GridFSFileMetadata:
    file_id: str
    filename: str
    content_type: str
    size_bytes: int
    uploaded_at: datetime
    image_type: Optional[str]
    game_slug: Optional[str]
    uploaded_by: Optional[str]
    metadata: dict[str, Any]


@dataclass(frozen=True)
class GridFSDownload:
    file_id: str
    filename: str
    content_type: str
    size_bytes: int
    uploaded_at: datetime
    metadata: dict[str, Any]
    stream: AsyncIterator[bytes]


class GridFSStorageService:
    def __init__(
        self,
        database: AsyncDatabase,
        *,
        bucket_name: str = DEFAULT_BUCKET_NAME,
        max_image_size_bytes: int = DEFAULT_MAX_IMAGE_SIZE_BYTES,
        chunk_size_bytes: int = DEFAULT_CHUNK_SIZE_BYTES,
    ) -> None:
        if max_image_size_bytes <= 0:
            raise ValueError(
                "max_image_size_bytes must be greater than zero."
            )

        if chunk_size_bytes <= 0:
            raise ValueError(
                "chunk_size_bytes must be greater than zero."
            )

        self.database = database
        self.bucket_name = bucket_name
        self.max_image_size_bytes = max_image_size_bytes
        self.chunk_size_bytes = chunk_size_bytes

        self.bucket = AsyncGridFSBucket(
            database,
            bucket_name=bucket_name,
            chunk_size_bytes=chunk_size_bytes,
        )

        self.files_collection = database[f"{bucket_name}.files"]
        self.chunks_collection = database[f"{bucket_name}.chunks"]
    @staticmethod
    def _utc_now() -> datetime:
        return datetime.now(timezone.utc)

    @staticmethod
    def _to_object_id(file_id: str | ObjectId) -> ObjectId:
        if isinstance(file_id, ObjectId):
            return file_id

        if not ObjectId.is_valid(file_id):
            raise GridFSInvalidFileError("Invalid GridFS file ID.")

        return ObjectId(file_id)

    @staticmethod
    def _sanitize_filename(filename: str, extension: str) -> str:
        original = Path(filename or "image").name.strip()
        stem = Path(original).stem.strip() or "image"

        safe_stem = "".join(
            character
            if character.isalnum() or character in {"-", "_"}
            else "-"
            for character in stem
        )

        while "--" in safe_stem:
            safe_stem = safe_stem.replace("--", "-")

        safe_stem = safe_stem.strip("-_") or "image"
        return f"{safe_stem}{extension}"

    async def create_indexes(self) -> None:
        await self.files_collection.create_index(
            [("metadata.game_slug", 1), ("metadata.image_type", 1)],
            name="idx_game_images_slug_type",
        )
        await self.files_collection.create_index(
            [("metadata.uploaded_by", 1), ("uploadDate", -1)],
            name="idx_game_images_uploader_date",
        )
        await self.files_collection.create_index(
            [("metadata.content_type", 1)],
            name="idx_game_images_content_type",
        )
        await self.files_collection.create_index(
            [("uploadDate", -1)],
            name="idx_game_images_upload_date",
        )

    async def upload_image(
        self,
        *,
        file: UploadFile,
        image_type: str,
        game_slug: Optional[str] = None,
        uploaded_by: Optional[str] = None,
        extra_metadata: Optional[dict[str, Any]] = None,
    ) -> GridFSFileMetadata:
        content_type = (file.content_type or "").lower().strip()

        if content_type not in ALLOWED_IMAGE_CONTENT_TYPES:
            raise GridFSInvalidFileError(
                "Only JPG, PNG, and WEBP image files are allowed."
            )

        extension = ALLOWED_IMAGE_CONTENT_TYPES[content_type]
        safe_filename = self._sanitize_filename(
            file.filename or "image",
            extension,
        )

        content = await file.read(self.max_image_size_bytes + 1)

        if not content:
            raise GridFSInvalidFileError("Uploaded image is empty.")

        if len(content) > self.max_image_size_bytes:
            raise GridFSFileTooLargeError(
                f"Image size must not exceed "
                f"{self.max_image_size_bytes // (1024 * 1024)} MB."
            )

        metadata: dict[str, Any] = {
            "content_type": content_type,
            "image_type": image_type,
            "game_slug": game_slug.strip().lower() if game_slug else None,
            "uploaded_by": uploaded_by,
            "uploaded_at": self._utc_now(),
            "original_filename": Path(file.filename or safe_filename).name,
        }

        if extra_metadata:
            metadata["extra"] = dict(extra_metadata)

        try:
            file_id = await self.bucket.upload_from_stream(
                safe_filename,
                content,
                metadata=metadata,
            )
        finally:
            await file.close()

        stored = await self.files_collection.find_one({"_id": file_id})

        if stored is None:
            raise GridFSStorageError(
                "Image was uploaded but its metadata could not be loaded."
            )

        return self._serialize_file_document(stored)

    async def get_metadata(
        self,
        file_id: str | ObjectId,
    ) -> GridFSFileMetadata:
        object_id = self._to_object_id(file_id)
        document = await self.files_collection.find_one({"_id": object_id})

        if document is None:
            raise GridFSFileNotFoundError("GridFS image not found.")

        return self._serialize_file_document(document)

    async def exists(self, file_id: str | ObjectId) -> bool:
        try:
            object_id = self._to_object_id(file_id)
        except GridFSInvalidFileError:
            return False

        return (
            await self.files_collection.count_documents(
                {"_id": object_id},
                limit=1,
            )
            > 0
        )

    async def delete_file(self, file_id: str | ObjectId) -> None:
        object_id = self._to_object_id(file_id)

        if not await self.exists(object_id):
            raise GridFSFileNotFoundError("GridFS image not found.")

        try:
            await self.bucket.delete(object_id)
        except NoFile as error:
            raise GridFSFileNotFoundError(
                "GridFS image not found."
            ) from error

    async def delete_many(
        self,
        file_ids: list[str | ObjectId],
        *,
        ignore_missing: bool = True,
    ) -> dict[str, list[str]]:
        deleted: list[str] = []
        missing: list[str] = []
        failed: list[str] = []

        seen: set[str] = set()

        for raw_file_id in file_ids:
            normalized = str(raw_file_id)

            if normalized in seen:
                continue

            seen.add(normalized)

            try:
                await self.delete_file(raw_file_id)
                deleted.append(normalized)
            except GridFSFileNotFoundError:
                missing.append(normalized)

                if not ignore_missing:
                    raise
            except Exception:
                failed.append(normalized)

        return {
            "deleted": deleted,
            "missing": missing,
            "failed": failed,
        }

    async def open_download(
        self,
        file_id: str | ObjectId,
        *,
        chunk_size_bytes: int = 64 * 1024,
    ) -> GridFSDownload:
        if chunk_size_bytes <= 0:
            raise ValueError("chunk_size_bytes must be greater than zero.")

        object_id = self._to_object_id(file_id)

        try:
            grid_out = await self.bucket.open_download_stream(object_id)
        except NoFile as error:
            raise GridFSFileNotFoundError(
                "GridFS image not found."
            ) from error

        metadata = dict(grid_out.metadata or {})
        content_type = (
            metadata.get("content_type")
            or "application/octet-stream"
        )

        async def stream_file() -> AsyncIterator[bytes]:
            try:
                while True:
                    chunk = await grid_out.read(chunk_size_bytes)

                    if not chunk:
                        break

                    yield chunk
            finally:
                grid_out.close()

        return GridFSDownload(
            file_id=str(grid_out._id),
            filename=grid_out.filename or "image",
            content_type=content_type,
            size_bytes=int(grid_out.length),
            uploaded_at=grid_out.upload_date,
            metadata=metadata,
            stream=stream_file(),
        )

    async def read_bytes(
        self,
        file_id: str | ObjectId,
    ) -> tuple[bytes, GridFSFileMetadata]:
        object_id = self._to_object_id(file_id)

        try:
            grid_out = await self.bucket.open_download_stream(object_id)
        except NoFile as error:
            raise GridFSFileNotFoundError(
                "GridFS image not found."
            ) from error

        try:
            content = await grid_out.read()
        finally:
            grid_out.close()

        metadata = await self.get_metadata(object_id)
        return content, metadata

    async def list_for_game(
        self,
        *,
        game_slug: str,
        image_type: Optional[str] = None,
        limit: int = 50,
    ) -> list[GridFSFileMetadata]:
        if limit < 1 or limit > 200:
            raise ValueError("limit must be between 1 and 200.")

        query: dict[str, Any] = {
            "metadata.game_slug": game_slug.strip().lower(),
        }

        if image_type:
            query["metadata.image_type"] = image_type

        cursor = (
            self.files_collection.find(query)
            .sort("uploadDate", -1)
            .limit(limit)
        )

        documents = await cursor.to_list(length=limit)
        return [
            self._serialize_file_document(document)
            for document in documents
        ]

    async def delete_for_game(
        self,
        game_slug: str,
    ) -> dict[str, list[str]]:
        files = await self.list_for_game(
            game_slug=game_slug,
            limit=200,
        )

        return await self.delete_many(
            [item.file_id for item in files],
            ignore_missing=True,
        )

    @staticmethod
    def _serialize_file_document(
        document: dict[str, Any],
    ) -> GridFSFileMetadata:
        metadata = dict(document.get("metadata") or {})
        upload_date = document.get("uploadDate") or metadata.get(
            "uploaded_at"
        )

        if upload_date is None:
            upload_date = datetime.now(timezone.utc)

        return GridFSFileMetadata(
            file_id=str(document["_id"]),
            filename=document.get("filename") or "image",
            content_type=metadata.get(
                "content_type",
                "application/octet-stream",
            ),
            size_bytes=int(document.get("length", 0)),
            uploaded_at=upload_date,
            image_type=metadata.get("image_type"),
            game_slug=metadata.get("game_slug"),
            uploaded_by=metadata.get("uploaded_by"),
            metadata=metadata,
        )