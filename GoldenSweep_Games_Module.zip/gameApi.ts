import axios from "axios";

import type {
    GameBulkBooleanResult,
    GameBulkDeleteResult,
    GameBulkStatusResult,
    GameCreate,
    GameDeleteResponse,
    GameFilter,
    GameImageDeleteResponse,
    GameImageMetadata,
    GameImageType,
    GameImageUploadResponse,
    GameImageValidationResponse,
    GameListResponse,
    GameMultiImageUploadResponse,
    GameResponse,
    GameStatisticsResponse,
    GameStatus,
    GameStatusResponse,
    GameUpdate,
} from "../types/game";

const rawBaseUrl = String(
    import.meta.env.VITE_API_BASE_URL ??
    import.meta.env.VITE_API_URL ??
    "http://localhost:8000/api"
).replace(/\/$/, "");

const API_BASE_URL = rawBaseUrl.endsWith("/api")
    ? rawBaseUrl
    : `${rawBaseUrl}/api`;

const api = axios.create({
    baseURL: API_BASE_URL,
    withCredentials: true,
    headers: {
        Accept: "application/json",
    },
});

class GameApi {
    // -- statistics ---------------------------------------------------

    async getStatistics() {
        const { data } = await api.get<GameStatisticsResponse>(
            "/admin/games/statistics"
        );

        return data;
    }

    // -- admin CRUD & listing ------------------------------------------

    async listAdminGames(filters: GameFilter) {
        const { data } = await api.get<GameListResponse>("/admin/games", {
            params: filters,
        });

        return data;
    }

    async getAdminGame(gameId: string) {
        const { data } = await api.get<GameResponse>(
            `/admin/games/${gameId}`
        );

        return data;
    }

    async createGame(payload: GameCreate) {
        const { data } = await api.post<GameResponse>(
            "/admin/games",
            payload
        );

        return data;
    }

    async updateGame(gameId: string, payload: GameUpdate) {
        const { data } = await api.patch<GameResponse>(
            `/admin/games/${gameId}`,
            payload
        );

        return data;
    }

    async deleteGame(gameId: string) {
        const { data } = await api.delete<GameDeleteResponse>(
            `/admin/games/${gameId}`
        );

        return data;
    }

    // -- status / feature / landing-page / ordering ---------------------

    async publishGame(gameId: string) {
        const { data } = await api.patch<GameResponse>(
            `/admin/games/${gameId}/publish`
        );

        return data;
    }

    async unpublishGame(gameId: string) {
        const { data } = await api.patch<GameResponse>(
            `/admin/games/${gameId}/unpublish`
        );

        return data;
    }

    async setGameStatus(gameId: string, status: GameStatus) {
        const { data } = await api.patch<GameResponse>(
            `/admin/games/${gameId}/status`,
            null,
            { params: { status } }
        );

        return data;
    }

    async featureGame(gameId: string) {
        const { data } = await api.patch<GameResponse>(
            `/admin/games/${gameId}/feature`
        );

        return data;
    }

    async unfeatureGame(gameId: string) {
        const { data } = await api.patch<GameResponse>(
            `/admin/games/${gameId}/unfeature`
        );

        return data;
    }

    async showOnLandingPage(gameId: string) {
        const { data } = await api.patch<GameResponse>(
            `/admin/games/${gameId}/show-on-landing-page`
        );

        return data;
    }

    async hideFromLandingPage(gameId: string) {
        const { data } = await api.patch<GameResponse>(
            `/admin/games/${gameId}/hide-from-landing-page`
        );

        return data;
    }

    async reorderGame(gameId: string, sortOrder: number) {
        const { data } = await api.patch<GameResponse>(
            `/admin/games/${gameId}/reorder`,
            { sort_order: sortOrder }
        );

        return data;
    }

    // -- images -----------------------------------------------------------

    async uploadGameImage(
        gameId: string,
        imageType: GameImageType,
        file: File
    ) {
        const form = new FormData();
        form.append("file", file);

        const { data } = await api.post<GameImageUploadResponse>(
            `/admin/games/${gameId}/images/${imageType}`,
            form,
            {
                headers: { "Content-Type": "multipart/form-data" },
            }
        );

        return data;
    }

    async uploadGameImages(
        gameId: string,
        files: Partial<Record<GameImageType, File>>
    ) {
        const form = new FormData();

        (Object.keys(files) as GameImageType[]).forEach((imageType) => {
            const file = files[imageType];
            if (file) form.append(imageType, file);
        });

        const { data } = await api.post<GameMultiImageUploadResponse>(
            `/admin/games/${gameId}/images`,
            form,
            {
                headers: { "Content-Type": "multipart/form-data" },
            }
        );

        return data;
    }

    async getGameImageMetadata(gameId: string, imageType: GameImageType) {
        const { data } = await api.get<GameImageMetadata>(
            `/admin/games/${gameId}/images/${imageType}`
        );

        return data;
    }

    async deleteGameImage(gameId: string, imageType: GameImageType) {
        const { data } = await api.delete<GameImageDeleteResponse>(
            `/admin/games/${gameId}/images/${imageType}`
        );

        return data;
    }

    async deleteAllGameImages(gameId: string) {
        const { data } = await api.delete<GameStatusResponse>(
            `/admin/games/${gameId}/images`
        );

        return data;
    }

    async validateGameImages(gameId: string) {
        const { data } = await api.get<GameImageValidationResponse>(
            `/admin/games/${gameId}/images/validate`
        );

        return data;
    }

    getImageUrl(fileId: string) {
        return `${API_BASE_URL}/games/image/${fileId}`;
    }

    // -- bulk operations ----------------------------------------------

    async bulkUpdateStatus(gameIds: string[], status: GameStatus) {
        const { data } = await api.post<GameBulkStatusResult>(
            "/admin/games/bulk/status",
            { game_ids: gameIds, status }
        );

        return data;
    }

    async bulkFeatureGames(gameIds: string[], isFeatured: boolean) {
        const { data } = await api.post<GameBulkBooleanResult>(
            "/admin/games/bulk/feature",
            { game_ids: gameIds, is_featured: isFeatured }
        );

        return data;
    }

    async bulkLandingPageUpdate(
        gameIds: string[],
        showOnLandingPage: boolean
    ) {
        const { data } = await api.post<GameBulkBooleanResult>(
            "/admin/games/bulk/landing-page",
            { game_ids: gameIds, show_on_landing_page: showOnLandingPage }
        );

        return data;
    }

    async bulkDeleteGames(gameIds: string[]) {
        const { data } = await api.post<GameBulkDeleteResult>(
            "/admin/games/bulk/delete",
            { game_ids: gameIds }
        );

        return data;
    }

    // -- public -------------------------------------------------------

    async listPublicGames(params: {
        page?: number;
        limit?: number;
        category?: string;
        featured_only?: boolean;
    }) {
        const { data } = await api.get<GameListResponse>("/games", {
            params,
        });

        return data;
    }

    async getPublicGame(slug: string) {
        const { data } = await api.get<GameResponse>(`/games/${slug}`);

        return data;
    }

    async registerGamePlay(gameId: string) {
        const { data } = await api.post<GameStatusResponse>(
            `/games/${gameId}/play`
        );

        return data;
    }
}

export const gameApi = new GameApi();

export default gameApi;