import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Plus } from "lucide-react";

import gameService from "../../services/gameService";

import type {
    GameFilter,
    GameResponse,
    GameStatisticsResponse,
} from "../../types/game";

import GameFilters from "../../components/admin/games/GameFilters";
import GameStatistics from "../../components/admin/games/GameStatistics";
import GameTable from "../../components/admin/games/GameTable";

const GamesList = () => {
    const navigate = useNavigate();

    const [loading, setLoading] = useState(false);

    const [games, setGames] = useState<GameResponse[]>([]);

    const [statistics, setStatistics] =
        useState<GameStatisticsResponse>({
            total_games: 0,
            published_games: 0,
            draft_games: 0,
            maintenance_games: 0,
            disabled_games: 0,
            featured_games: 0,
            landing_page_games: 0,
            total_play_count: 0,
        });

    const [filters, setFilters] =
        useState<GameFilter>({
            page: 1,
            limit: 20,
        });

    const loadStatistics = async () => {
        try {
            const response =
                await gameService.getStatistics();

            setStatistics(response);
        } catch (error) {
            console.error(error);
        }
    };

    const loadGames = async () => {
        try {
            setLoading(true);

            const response =
                await gameService.listAdminGames(
                    filters,
                );

            setGames(response.games);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadStatistics();
    }, []);

    useEffect(() => {
        loadGames();
    }, [filters]);

    const publishGame = async (
        game: GameResponse,
    ) => {
        await gameService.publishGame(game.id);

        await loadGames();

        await loadStatistics();
    };

    const unpublishGame = async (
        game: GameResponse,
    ) => {
        await gameService.unpublishGame(game.id);

        await loadGames();

        await loadStatistics();
    };

    const deleteGame = async (
        game: GameResponse,
    ) => {
        const confirmed = window.confirm(
            `Delete "${game.name}"?`,
        );

        if (!confirmed) return;

        await gameService.deleteGame(
            game.id,
        );

        await loadGames();

        await loadStatistics();
    };

    return (
        <div className="space-y-6">

            <div className="flex items-center justify-between">

                <div>

                    <h1 className="text-3xl font-bold">
                        Games
                    </h1>

                    <p className="text-gray-500 mt-1">
                        GoldenSweep Games Management
                    </p>

                </div>

                <button
                    onClick={() =>
                        navigate(
                            "/admin/games/create",
                        )
                    }
                    className="flex items-center gap-2 rounded-lg bg-yellow-500 px-5 py-3 font-semibold text-white hover:bg-yellow-600"
                >
                    <Plus size={18} />

                    Create Game

                </button>

            </div>

            <GameStatistics
                statistics={statistics}
            />

            <GameFilters
                filters={filters}
                onChange={setFilters}
            />

            <GameTable
                games={games}
                loading={loading}
                onView={(game) =>
                    navigate(
                        `/admin/games/${game.id}`,
                    )
                }
                onEdit={(game) =>
                    navigate(
                        `/admin/games/${game.id}/edit`,
                    )
                }
                onDelete={deleteGame}
                onPublish={publishGame}
                onUnpublish={unpublishGame}
            />

        </div>
    );
};

export default GamesList;