import {
    Eye,
    Pencil,
    Trash2,
    Play,
    Pause,
    Star,
    ImageOff,
    Loader2,
} from "lucide-react";

import type { GameResponse } from "../../../types/game";
import gameService from "../../../services/gameService";
import GameStatusBadge from "./GameStatusBadge";

interface GameTableProps {
    games?: GameResponse[] | null;
    loading?: boolean;
    onView: (game: GameResponse) => void;
    onEdit: (game: GameResponse) => void;
    onDelete: (game: GameResponse) => void;
    onPublish: (game: GameResponse) => void;
    onUnpublish: (game: GameResponse) => void;
}

const formatCategory = (category?: string): string => {
    if (!category) {
        return "Other";
    }

    return category
        .split("_")
        .map(
            (word) =>
                word.charAt(0).toUpperCase() +
                word.slice(1)
        )
        .join(" ");
};

const formatDate = (date?: string): string => {
    if (!date) {
        return "—";
    }

    const parsedDate = new Date(date);

    if (Number.isNaN(parsedDate.getTime())) {
        return "—";
    }

    return parsedDate.toLocaleDateString("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric",
    });
};

const GameTable = ({
    games = [],
    loading = false,
    onView,
    onEdit,
    onDelete,
    onPublish,
    onUnpublish,
}: GameTableProps) => {
    const safeGames = Array.isArray(games) ? games : [];

    return (
        <div className="overflow-hidden rounded-xl border bg-white shadow-sm">
            <div className="overflow-x-auto">
                <table className="w-full min-w-[900px] text-left text-sm">
                    <thead className="border-b bg-gray-50 text-xs uppercase text-gray-500">
                        <tr>
                            <th className="px-4 py-3">Game</th>
                            <th className="px-4 py-3">Provider</th>
                            <th className="px-4 py-3">Category</th>
                            <th className="px-4 py-3">Status</th>
                            <th className="px-4 py-3">Plays</th>
                            <th className="px-4 py-3">Updated</th>
                            <th className="px-4 py-3 text-right">
                                Actions
                            </th>
                        </tr>
                    </thead>

                    <tbody className="divide-y">
                        {loading && (
                            <tr>
                                <td
                                    colSpan={7}
                                    className="px-4 py-12 text-center"
                                >
                                    <Loader2
                                        size={28}
                                        className="mx-auto animate-spin text-yellow-500"
                                    />

                                    <p className="mt-2 text-sm text-gray-400">
                                        Loading games...
                                    </p>
                                </td>
                            </tr>
                        )}

                        {!loading && safeGames.length === 0 && (
                            <tr>
                                <td
                                    colSpan={7}
                                    className="px-4 py-12 text-center text-gray-400"
                                >
                                    No games found.
                                </td>
                            </tr>
                        )}

                        {!loading &&
                            safeGames.map((game) => {
                                const title =
                                    game.name?.trim() ||
                                    "Untitled Game";

                                const thumbnailUrl =
                                    game.thumbnail_file_id
                                        ? gameService.getImageUrl(game.thumbnail_file_id)
                                        : undefined;

                                return (
                                    <tr
                                        key={game.id}
                                        className="hover:bg-gray-50"
                                    >
                                        <td className="px-4 py-3">
                                            <div className="flex items-center gap-3">
                                                {thumbnailUrl ? (
                                                    <img
                                                        src={thumbnailUrl}
                                                        alt={title}
                                                        className="h-12 w-12 rounded-lg object-cover"
                                                        loading="lazy"
                                                        onError={(event) => {
                                                            event.currentTarget.style.display =
                                                                "none";
                                                        }}
                                                    />
                                                ) : (
                                                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-400">
                                                        <ImageOff
                                                            size={18}
                                                        />
                                                    </div>
                                                )}

                                                <div className="min-w-0">
                                                    <p className="flex items-center gap-1 font-semibold text-gray-800">
                                                        <span className="max-w-[220px] truncate">
                                                            {title}
                                                        </span>

                                                        {game.is_featured && (
                                                            <Star
                                                                size={14}
                                                                className="shrink-0 fill-yellow-400 text-yellow-400"
                                                            />
                                                        )}
                                                    </p>

                                                    <p className="max-w-[220px] truncate text-xs text-gray-400">
                                                        {game.slug ||
                                                            "No slug"}
                                                    </p>
                                                </div>
                                            </div>
                                        </td>

                                        <td className="px-4 py-3 text-gray-600">
                                            {game.provider_name || "—"}
                                        </td>

                                        <td className="px-4 py-3 text-gray-600">
                                            {formatCategory(
                                                game.category
                                            )}
                                        </td>

                                        <td className="px-4 py-3">
                                            <GameStatusBadge
                                                status={
                                                    game.status ||
                                                    "draft"
                                                }
                                            />
                                        </td>

                                        <td className="px-4 py-3 text-gray-600">
                                            {Number(
                                                game.play_count ?? 0
                                            ).toLocaleString(
                                                "en-US"
                                            )}
                                        </td>

                                        <td className="px-4 py-3 text-gray-500">
                                            {formatDate(
                                                game.updated_at
                                            )}
                                        </td>

                                        <td className="px-4 py-3">
                                            <div className="flex items-center justify-end gap-2">
                                                <button
                                                    type="button"
                                                    onClick={() =>
                                                        onView(game)
                                                    }
                                                    title="View game"
                                                    aria-label={`View ${title}`}
                                                    className="rounded-lg border p-2 text-gray-600 transition hover:bg-gray-100"
                                                >
                                                    <Eye size={16} />
                                                </button>

                                                <button
                                                    type="button"
                                                    onClick={() =>
                                                        onEdit(game)
                                                    }
                                                    title="Edit game"
                                                    aria-label={`Edit ${title}`}
                                                    className="rounded-lg border p-2 text-blue-600 transition hover:bg-blue-50"
                                                >
                                                    <Pencil
                                                        size={16}
                                                    />
                                                </button>

                                                {game.status ===
                                                "published" ? (
                                                    <button
                                                        type="button"
                                                        onClick={() =>
                                                            onUnpublish(
                                                                game
                                                            )
                                                        }
                                                        title="Unpublish game"
                                                        aria-label={`Unpublish ${title}`}
                                                        className="rounded-lg border p-2 text-orange-600 transition hover:bg-orange-50"
                                                    >
                                                        <Pause
                                                            size={16}
                                                        />
                                                    </button>
                                                ) : (
                                                    <button
                                                        type="button"
                                                        onClick={() =>
                                                            onPublish(
                                                                game
                                                            )
                                                        }
                                                        title="Publish game"
                                                        aria-label={`Publish ${title}`}
                                                        className="rounded-lg border p-2 text-green-600 transition hover:bg-green-50"
                                                    >
                                                        <Play
                                                            size={16}
                                                        />
                                                    </button>
                                                )}

                                                <button
                                                    type="button"
                                                    onClick={() =>
                                                        onDelete(game)
                                                    }
                                                    title="Delete game"
                                                    aria-label={`Delete ${title}`}
                                                    className="rounded-lg border p-2 text-red-600 transition hover:bg-red-50"
                                                >
                                                    <Trash2
                                                        size={16}
                                                    />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                );
                            })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default GameTable;