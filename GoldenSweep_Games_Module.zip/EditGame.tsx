import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Loader2 } from "lucide-react";

import GameForm from "../../components/admin/games/GameForm";
import gameService from "../../services/gameService";

import type {
    GameResponse,
    GameUpdate,
} from "../../types/game";

const EditGame = () => {
    const navigate = useNavigate();

    const { gameId } = useParams();

    const [loading, setLoading] = useState(false);

    const [pageLoading, setPageLoading] =
        useState(true);

    const [game, setGame] =
        useState<GameResponse>();

    const loadGame = async () => {
        if (!gameId) return;

        try {
            setPageLoading(true);

            const response =
                await gameService.getAdminGame(
                    gameId,
                );

            setGame(response);
        } catch (error) {
            console.error(error);

            alert("Unable to load game.");

            navigate("/admin/games");
        } finally {
            setPageLoading(false);
        }
    };

    useEffect(() => {
        loadGame();
    }, [gameId]);

    const updateGame = async (
        values: GameUpdate,
    ) => {
        if (!gameId) return;

        try {
            setLoading(true);

            await gameService.updateGame(
                gameId,
                values,
            );

            navigate(
                `/admin/games/${gameId}`,
            );
        } catch (error) {
            console.error(error);

            alert("Unable to update game.");
        } finally {
            setLoading(false);
        }
    };

    if (pageLoading) {
        return (
            <div className="flex h-[60vh] items-center justify-center">

                <Loader2
                    className="animate-spin text-yellow-500"
                    size={40}
                />

            </div>
        );
    }

    if (!game) {
        return (
            <div className="rounded-xl bg-white p-8 text-center shadow">

                <h2 className="text-2xl font-semibold">

                    Game Not Found

                </h2>

            </div>
        );
    }

    return (
        <div className="space-y-6">

            <div className="flex items-center gap-4">

                <button
                    onClick={() =>
                        navigate("/admin/games")
                    }
                    className="rounded-lg border bg-white p-2 hover:bg-gray-100"
                >
                    <ArrowLeft size={20} />
                </button>

                <div>

                    <h1 className="text-3xl font-bold">

                        Edit Game

                    </h1>

                    <p className="text-gray-500">

                        {game.name}

                    </p>

                </div>

            </div>

            <GameForm
                mode="edit"
                loading={loading}
                initialValues={game}
                onSubmit={updateGame}
                onCancel={() =>
                    navigate(
                        `/admin/games/${game.id}`,
                    )
                }
            />

        </div>
    );
};

export default EditGame;