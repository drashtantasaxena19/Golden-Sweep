import type { GameStatus } from "../../../types/game";

interface GameStatusBadgeProps {
    status: GameStatus;
}

const STATUS_STYLES: Record<GameStatus, string> = {
    draft: "bg-gray-100 text-gray-700",
    published: "bg-green-100 text-green-700",
    maintenance: "bg-orange-100 text-orange-700",
    disabled: "bg-red-100 text-red-700",
};

const STATUS_LABELS: Record<GameStatus, string> = {
    draft: "Draft",
    published: "Published",
    maintenance: "Maintenance",
    disabled: "Disabled",
};

const GameStatusBadge = ({ status }: GameStatusBadgeProps) => {
    return (
        <span
            className={`inline-flex items-center rounded-full px-3 py-1 text-sm font-medium ${STATUS_STYLES[status]}`}
        >
            {STATUS_LABELS[status]}
        </span>
    );
};

export default GameStatusBadge;