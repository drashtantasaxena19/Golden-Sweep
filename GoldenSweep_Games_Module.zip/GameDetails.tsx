import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
    ArrowLeft,
    Pencil,
    Trash2,
    Play,
    Pause,
    Loader2,
    Star,
    ImageIcon,
    ExternalLink,
} from "lucide-react";

import gameApi from "../../api/gameApi";
import gameService from "../../services/gameService";
import type { GameResponse } from "../../types/game";
import GameStatusBadge from "../../components/admin/games/GameStatusBadge";

const GameDetails = () => {
    const navigate = useNavigate();
    const { gameId } = useParams();

    const [loading, setLoading] = useState(true);
    const [game, setGame] = useState<GameResponse>();

    const loadGame = async () => {
        if (!gameId) return;

        try {
            setLoading(true);

            const response = await gameService.getAdminGame(gameId);

            setGame(response);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadGame();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [gameId]);

    const publish = async () => {
        if (!game) return;

        try {
            await gameService.publishGame(game.id);
            loadGame();
        } catch (error) {
            console.error(error);
            alert("Unable to publish game. Make sure it has a thumbnail.");
        }
    };

    const unpublish = async () => {
        if (!game) return;

        await gameService.unpublishGame(game.id);
        loadGame();
    };

    const deleteGame = async () => {
        if (!game) return;

        if (!window.confirm("Delete this game?")) return;

        await gameService.deleteGame(game.id);
        navigate("/admin/games");
    };

    if (loading) {
        return (
            <div className="flex h-[70vh] items-center justify-center">
                <Loader2
                    className="animate-spin text-yellow-500"
                    size={40}
                />
            </div>
        );
    }

    if (!game) {
        return (
            <div className="rounded-xl bg-white p-10 text-center">
                <h2 className="text-2xl font-bold">Game not found</h2>
            </div>
        );
    }

    const bannerUrl = game.banner_file_id
        ? gameApi.getImageUrl(game.banner_file_id)
        : game.thumbnail_file_id
            ? gameApi.getImageUrl(game.thumbnail_file_id)
            : game.logo_file_id
                ? gameApi.getImageUrl(game.logo_file_id)
                : "https://placehold.co/900x400?text=GoldenSweep";

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <button
                        onClick={() => navigate("/admin/games")}
                        className="rounded-lg border bg-white p-2 hover:bg-gray-100"
                    >
                        <ArrowLeft size={20} />
                    </button>

                    <div>
                        <h1 className="text-3xl font-bold">{game.name}</h1>
                        <p className="text-gray-500">
                            {game.provider_name ?? "No provider set"}
                        </p>
                    </div>
                </div>

                <div className="flex gap-3">
                    <button
                        onClick={() =>
                            navigate(`/admin/games/${game.id}/edit`)
                        }
                        className="flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-3 text-white"
                    >
                        <Pencil size={18} />
                        Edit
                    </button>

                    {game.status === "published" ? (
                        <button
                            onClick={unpublish}
                            className="flex items-center gap-2 rounded-lg bg-orange-500 px-5 py-3 text-white"
                        >
                            <Pause size={18} />
                            Unpublish
                        </button>
                    ) : (
                        <button
                            onClick={publish}
                            className="flex items-center gap-2 rounded-lg bg-green-600 px-5 py-3 text-white"
                        >
                            <Play size={18} />
                            Publish
                        </button>
                    )}

                    <button
                        onClick={deleteGame}
                        className="flex items-center gap-2 rounded-lg bg-red-600 px-5 py-3 text-white"
                    >
                        <Trash2 size={18} />
                        Delete
                    </button>
                </div>
            </div>

            <div className="grid gap-6 lg:grid-cols-3">
                <div className="rounded-xl border bg-white p-6 shadow-sm lg:col-span-2">
                    <img
                        src={bannerUrl}
                        alt={game.name}
                        className="h-80 w-full rounded-xl object-cover"
                    />

                    <div className="mt-6">
                        <h2 className="text-2xl font-bold">{game.name}</h2>

                        <div className="mt-3 flex flex-wrap gap-3">
                            <GameStatusBadge status={game.status} />

                            {game.is_featured && (
                                <span className="flex items-center gap-1 rounded-full bg-yellow-100 px-3 py-1 text-yellow-700">
                                    <Star size={15} />
                                    Featured
                                </span>
                            )}

                            {game.show_on_landing_page && (
                                <span className="rounded-full bg-green-100 px-3 py-1 text-green-700">
                                    Landing Page
                                </span>
                            )}
                        </div>

                        <p className="mt-6 whitespace-pre-wrap text-gray-700">
                            {game.short_description}
                        </p>

                        <p className="mt-4 whitespace-pre-wrap text-gray-600">
                            {game.description}
                        </p>

                        {game.tags.length > 0 && (
                            <div className="mt-4 flex flex-wrap gap-2">
                                {game.tags.map((tag) => (
                                    <span
                                        key={tag}
                                        className="rounded-full bg-gray-100 px-3 py-1 text-xs text-gray-600"
                                    >
                                        #{tag}
                                    </span>
                                ))}
                            </div>
                        )}
                    </div>
                </div>

                <div className="rounded-xl border bg-white p-6 shadow-sm">
                    <h2 className="mb-5 text-xl font-semibold">
                        Information
                    </h2>

                    <div className="space-y-4">
                        <Info
                            label="Provider"
                            value={game.provider_name ?? "—"}
                        />
                        <Info
                            label="Category"
                            value={game.category.replaceAll("_", " ")}
                        />
                        <Info label="Slug" value={game.slug} />
                        <Info
                            label="Entry Fee"
                            value={`${game.entry_fee_coins} coins`}
                        />
                        <Info
                            label="Minimum Age"
                            value={String(game.minimum_age)}
                        />
                        <Info
                            label="Orientation"
                            value={game.orientation}
                        />
                        <Info
                            label="Total Plays"
                            value={String(game.play_count)}
                        />
                        <Info
                            label="Created"
                            value={new Date(
                                game.created_at
                            ).toLocaleString()}
                        />
                        <Info
                            label="Updated"
                            value={new Date(
                                game.updated_at
                            ).toLocaleString()}
                        />
                    </div>

                    <a
                        href={game.game_url}
                        target="_blank"
                        rel="noreferrer"
                        className="mt-8 flex items-center justify-center gap-2 rounded-lg bg-yellow-500 py-3 font-semibold text-white"
                    >
                        <ExternalLink size={18} />
                        Open Game
                    </a>
                </div>
            </div>

            <div className="grid gap-6 md:grid-cols-3">
                <ImageCard
                    title="Logo"
                    fileId={game.logo_file_id}
                />
                <ImageCard
                    title="Thumbnail"
                    fileId={game.thumbnail_file_id}
                />
                <ImageCard
                    title="Banner"
                    fileId={game.banner_file_id}
                />
            </div>
        </div>
    );
};

interface InfoProps {
    label: string;
    value: string;
}

const Info = ({ label, value }: InfoProps) => (
    <div>
        <p className="text-sm text-gray-500">{label}</p>
        <p className="font-semibold capitalize">{value}</p>
    </div>
);

interface ImageCardProps {
    title: string;
    fileId?: string | null;
}

const ImageCard = ({ title, fileId }: ImageCardProps) => (
    <div className="rounded-xl border bg-white p-4 shadow-sm">
        <h3 className="mb-4 text-lg font-semibold">{title}</h3>

        {fileId ? (
            <img
                src={gameApi.getImageUrl(fileId)}
                alt={title}
                className="h-56 w-full rounded-lg object-cover"
            />
        ) : (
            <div className="flex h-56 items-center justify-center rounded-lg border bg-gray-100">
                <ImageIcon size={42} className="text-gray-400" />
            </div>
        )}
    </div>
);

export default GameDetails;